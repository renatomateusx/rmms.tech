#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.gcp.compute import Run, GKE
from diagrams.gcp.analytics import PubSub, Dataflow, BigQuery
from diagrams.gcp.devtools import Build
from diagrams.gcp.operations import Monitoring
from diagrams.gcp.ml import AIPlatform
from diagrams.onprem.client import User
from diagrams.onprem.network import Internet
from diagrams.generic.storage import Storage
from diagrams.generic.network import Firewall

with Diagram("Banco Digital Seguro - Arquitetura", show=False, filename="images/banco_architecture", outformat="png"):
    
    user = User("Cliente")
    internet = Internet("Internet")
    
    with Cluster("Google Cloud Platform"):
        with Cluster("Segurança"):
            armor = Firewall("Cloud Armor")
            secret_manager = Storage("Secret Manager")
        
        with Cluster("Processamento de Pagamentos"):
            with Cluster("Serverless"):
                fn1 = Run("Autorização")
                fn2 = Run("Processamento")
                fn3 = Run("Liquidação")
        
        with Cluster("Sistema Anti-Fraude"):
            dataflow = Dataflow("Dataflow")
            bigquery = BigQuery("BigQuery")
            ai = AIPlatform("AI Platform")
        
        with Cluster("CI/CD Pipeline"):
            cicd = Build("Cloud Build")
        
        with Cluster("Observabilidade"):
            monitoring = Monitoring("Cloud Monitoring")
    
    # Fluxo principal
    user >> internet >> armor >> fn1
    fn1 >> fn2 >> fn3
    
    # Sistema anti-fraude
    fn1 >> dataflow
    dataflow >> bigquery
    bigquery >> ai
    ai >> fn1
    
    # Segurança
    fn1 >> secret_manager
    fn2 >> secret_manager
    fn3 >> secret_manager
    
    # Monitoramento
    monitoring << fn1
    monitoring << fn2
    monitoring << fn3
    monitoring << dataflow
    monitoring << bigquery
    monitoring << ai
    
    # CI/CD
    cicd >> Edge(color="brown", style="dashed") >> fn1
    cicd >> Edge(color="brown", style="dashed") >> fn2
    cicd >> Edge(color="brown", style="dashed") >> fn3
