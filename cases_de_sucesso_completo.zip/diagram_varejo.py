#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.gcp.compute import GKE, Run
from diagrams.aws.compute import EC2
from diagrams.gcp.network import LoadBalancing
from diagrams.gcp.analytics import PubSub, Dataflow
from diagrams.gcp.devtools import Build
from diagrams.gcp.operations import Monitoring
from diagrams.gcp.storage import Storage
from diagrams.gcp.database import Memorystore
from diagrams.custom import Custom
from diagrams.onprem.client import User
from diagrams.onprem.network import Internet

with Diagram("Mega Varejo Online - Arquitetura", show=False, filename="images/varejo_architecture", outformat="png"):
    
    user = User("Cliente")
    internet = Internet("Internet")
    
    with Cluster("Arquitetura Multi-Cloud"):
        with Cluster("Google Cloud Platform (Principal)"):
            api_gateway = Custom("Apigee API Management", "./images/apigee.png")
            
            with Cluster("CI/CD Pipeline"):
                cicd = Build("Cloud Build")
            
            with Cluster("Serviços de Pagamento"):
                lb = LoadBalancing("Load Balancer")
                with Cluster("Processadores"):
                    payment1 = Run("Processador 1")
                    payment2 = Run("Processador 2")
                    payment3 = Run("Processador 3")
            
            with Cluster("Caching e Filas"):
                redis = Memorystore("Redis")
                pubsub = PubSub("Pub/Sub")
            
            with Cluster("Observabilidade"):
                monitoring = Monitoring("Cloud Operations")
        
        with Cluster("AWS (Contingência)"):
            aws_payment = EC2("Serviço de Backup")
    
    # Fluxo principal
    user >> internet >> api_gateway
    api_gateway >> lb
    lb >> payment1
    lb >> payment2
    lb >> payment3
    
    # Caching e filas
    api_gateway >> redis
    api_gateway >> pubsub
    pubsub >> payment1
    pubsub >> payment2
    pubsub >> payment3
    
    # Contingência
    api_gateway >> Edge(color="red", style="dashed") >> aws_payment
    
    # Monitoramento
    monitoring << api_gateway
    monitoring << payment1
    monitoring << payment2
    monitoring << payment3
    monitoring << redis
    monitoring << pubsub
    
    # CI/CD
    cicd >> Edge(color="brown", style="dashed") >> payment1
    cicd >> Edge(color="brown", style="dashed") >> payment2
    cicd >> Edge(color="brown", style="dashed") >> payment3
