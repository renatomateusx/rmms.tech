#!/usr/bin/env python3
from diagrams import Diagram, Cluster, Edge
from diagrams.gcp.compute import GKE, Run
from diagrams.gcp.analytics import PubSub, Dataflow
from diagrams.gcp.devtools import Build
from diagrams.gcp.operations import Monitoring
from diagrams.gcp.storage import Storage
from diagrams.gcp.database import Spanner
from diagrams.onprem.client import User
from diagrams.onprem.network import Internet

with Diagram("Fintech Pagamentos Rápidos - Arquitetura", show=False, filename="images/fintech_architecture", outformat="png"):
    
    user = User("Cliente")
    internet = Internet("Internet")
    
    with Cluster("Google Cloud Platform"):
        with Cluster("CI/CD Pipeline"):
            cicd = Build("Cloud Build")
        
        with Cluster("Microserviços de Pagamento"):
            gke = GKE("GKE")
            with Cluster("Serviços"):
                auth = Run("Autorização")
                process = Run("Processamento")
                settle = Run("Liquidação")
        
        with Cluster("Processamento de Eventos"):
            pubsub = PubSub("Pub/Sub")
            dataflow = Dataflow("Dataflow")
        
        with Cluster("Armazenamento"):
            db = Spanner("Spanner")
            storage = Storage("Cloud Storage")
        
        with Cluster("Observabilidade"):
            monitoring = Monitoring("Cloud Monitoring")
    
    # Fluxo
    user >> internet >> auth
    auth >> pubsub >> dataflow
    dataflow >> process >> settle
    process >> db
    settle >> storage
    
    # Monitoramento
    monitoring << auth
    monitoring << process
    monitoring << settle
    monitoring << pubsub
    monitoring << dataflow
    
    # CI/CD
    cicd >> Edge(color="brown", style="dashed") >> gke
